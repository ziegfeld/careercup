package Question7_6;

public class GraphPoint {
	public double x;
	public double y;
	public GraphPoint(double x1, double y1) {
		x = x1;
		y = y1;
	}
}
