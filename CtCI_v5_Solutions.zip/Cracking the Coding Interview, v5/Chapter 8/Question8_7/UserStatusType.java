package Question8_7;

public enum UserStatusType {
	Offline, Away, Idle, Available, Busy
}
