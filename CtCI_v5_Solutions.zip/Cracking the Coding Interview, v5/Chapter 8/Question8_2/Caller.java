package Question8_2;

public class Caller {
	private String name;
	private int userId;
	public Caller(int id, String nm) {
		name = nm;
		userId = id;
	}
}
