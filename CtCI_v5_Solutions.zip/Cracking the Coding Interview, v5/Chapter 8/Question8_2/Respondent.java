package Question8_2;

class Respondent extends Employee {
    public Respondent() {
    	rank = Rank.Responder;
    }
}
