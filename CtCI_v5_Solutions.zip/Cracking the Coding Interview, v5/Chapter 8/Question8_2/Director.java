package Question8_2;

class Director extends Employee {
    public Director() {
    	rank = Rank.Director;
    }
}
