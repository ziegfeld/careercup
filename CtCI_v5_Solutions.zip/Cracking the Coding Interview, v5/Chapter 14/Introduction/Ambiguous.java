package Introduction;

public class Ambiguous extends Shape {
	private double area = 10;
	
	public double computeArea() {
		return area;
	}
}
